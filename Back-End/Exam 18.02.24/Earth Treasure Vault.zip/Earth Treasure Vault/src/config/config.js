module.exports = {
    SECRET: 'JARp*bCx@fLXF(0Y6O>X:@36z$[Bo0'
};